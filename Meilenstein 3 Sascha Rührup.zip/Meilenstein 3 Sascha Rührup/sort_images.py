import os

folderpath = "images/Faces/"
destpath = "images/"
files = os.listdir(folderpath)

for index, file in enumerate(files):
    split = file.split('_')