import itertools
import os
import csv
import re
import shutil
from collections import Counter
from datetime import datetime

import cv2
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.utils import shuffle


def generate_csv(folderpath, csv_filename):
    """extracts labels from image name and generates csv file with data"""
    image_file_names = os.listdir(folderpath)

    with open(csv_filename, 'w', newline='') as csvfile:
        # declare columns
        fieldnames = ['image_path', 'image_index', 'is_face', 'age_output', 'gender_output']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

        writer.writeheader()

        # extract labels from filename and save to .csv file
        for name in image_file_names:
            split = name.split('_')
            age = int(split[0])
            gender = int(split[1])
            face = int(split[2])
            image_path = os.path.join(folderpath, name)
            image_index = split[3][:-5]
            writer.writerow({'image_path': image_path, 'image_index': image_index, 'is_face': face, 'age_output': age,
                             'gender_output': gender})


# Load labels from CSV file
def load_labels_from_csv(csv_filename):
    """convert data from csv file to paths and labels"""
    df = pd.read_csv(csv_filename)

    df = shuffle(df)
    # Extract image paths and labels
    return_img_paths = df['image_path'].tolist()
    face_labels = df['is_face'].tolist()
    age_labels = df['age_output'].tolist()
    gender_labels = df['gender_output'].tolist()

    # Combine labels
    return_labels = {'is_face': face_labels, 'age_output': age_labels, 'gender_output': gender_labels}

    return return_img_paths, return_labels


def move_files_with_less_occurrences(threshold, src_dir, dest_dir):
    """remove all images, which have an age that is represented less often in all Images than threshold"""
    image_file_names = os.listdir(src_dir)
    values = [int(re.match(r'^(\d+)_', filename).group(1)) for filename in image_file_names]

    # Count the occurrences of each age
    values_with_zeros = [str(value).zfill(3) for value in values]
    count_per_number = Counter(values_with_zeros)

    count_values = [count_per_number[str(value).zfill(3)] for value in values]

    for filename, count_value in zip(image_file_names, count_values):
        if count_value < threshold:
            source_path = os.path.join(src_dir, filename)
            destination_path = os.path.join(dest_dir, filename)
            shutil.move(source_path, destination_path)
            print(f"Moved file: {filename}")

    # Display the results for occurrences less than the threshold
    for number, count in count_per_number.items():
        if count < threshold:
            print(f"Number {number}: {count} occurrences")


def generate_plot_example_images_labeled(dataset, log_dir_plot):
    """not adjusted for Multi-Task learning"""
    image_batch, label_batch = next(iter(dataset))
    plt.figure(figsize=(10, 10))
    for i in range(9):
        ax = plt.subplot(3, 3, i + 1)
        plt.imshow(image_batch[i].numpy().astype("uint8"))
        class_identifier = "Face" if label_batch[i].numpy() == 1 else "No Face"
        plt.title(class_identifier)
        plt.axis("off")
    plt.savefig(fname=log_dir_plot + datetime.now().strftime("%Y%m%d-%H%M%S"), bbox_inches='tight')
    return


def prepare_image_for_predict(filename, shape, filepath):
    img = cv2.imread(filepath+filename)
    img = cv2.resize(img, shape)
    img = (img / 127.5) - 1.0
    img = np.expand_dims(img, axis=0)
    return img

# move_files_with_less_occurrences(75, 'images\\', 'low_sample_size\\')
