import os
import shutil


def move_jpg_files(source_folder, destination_folder):
    # Iterate through all files in the source folder and its subdirectories
    for foldername, subfolders, filenames in os.walk(source_folder):
        for filename in filenames:
            # Check if the file has a ".jpg" extension
            if filename.endswith(".jpg"):
                # Construct the full paths for the source and destination
                source_path = os.path.join(foldername, filename)
                destination_path = os.path.join(destination_folder, filename)

                # Move the file to the destination folder
                shutil.move(source_path, destination_path)
                print(f"Moved: {source_path} to {destination_path}")


# Replace these paths with your actual source and destination paths
source_folder = 'monkeys\\'
destination_folder = 'monkeys\\'

# Call the function to move the .jpg files
move_jpg_files(source_folder, destination_folder)
