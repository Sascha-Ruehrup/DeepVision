import math
import tensorflow as tf
from tensorflow import keras
from keras import layers
import pandas as pd
import numpy as np
import cv2
import utils
from sklearn.metrics import confusion_matrix

###
# data legend:
# gender 0 male, 1 female, 2 no gender
# face 0 no_face, 1 face
# age value 1-116, 0 no age
# age_gender_face_imgindex.jpeg
# ca. 16.000 Not Face
# ca. 23.000 Face
###

# TODO extract Settings into separate file

# Dataset
IMAGE_WIDTH = 224
IMAGE_HEIGHT = 224
size = (IMAGE_HEIGHT, IMAGE_WIDTH)
RANDOM_SEED = 1
BATCH_SIZE = 32

# Run name
run_name = 'run_test_v2'

# Paths
log_dir_plots = "logs/plots/"
normal_log_dir = "logs/normal_training/"
fine_tuning_log_dir = "logs/fine_tuning/"
path_images = "images/"
checkpoint_dir = "checkpoints/"
model_save_path = "models/"

# Data Augmentation
RANDOM_ROTATION = 0.2

# MobileNet
transfer_learning = True
LOAD_CHECKPOINT = True
load_checkpoint_path = "runs/v2/multitask_v2"

# Callbacks
LOG_TENSORBOARD = False
early_stopping_callback = False
save_model_weights_as_checkpoint = False

# normal Training
do_training = False
TRAINING_EPOCHS = 5
# weights
is_face_weight = 1
gender_weight = 1
age_weight = 10

# Save Model
model_name = run_name + ".keras"
SAVE_MODEL = False

# use saved Model
USE_SAVED_MODEL = False
saved_model_path = 'models/run_test_v1.keras'

# Evaluation
CUSTOM_PREDICTION = True
EVALUATE_MODEL = False

physical_devices = tf.config.experimental.list_physical_devices('GPU')
print("Num GPUs Available: ", len(physical_devices))
if len(physical_devices) > 0:
    tf.config.experimental.set_memory_growth(physical_devices[0], True)
    print('memory growth set')


def get_callbacks(training_mode='normal'):
    """collects callbacks for model.fit()"""
    callbacks = []
    # log data for tensorBoard
    if LOG_TENSORBOARD:
        if training_mode == 'normal':
            dir_path = normal_log_dir + run_name
        else:  # training_mode == 'fine_tuning':
            dir_path = fine_tuning_log_dir + run_name

        tb_callback = tf.keras.callbacks.TensorBoard(log_dir=dir_path, histogram_freq=1)
        callbacks.append(tb_callback)

    if early_stopping_callback:
        es_callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=3)
        callbacks.append(es_callback)

    if save_model_weights_as_checkpoint:
        checkpoint_path = checkpoint_dir + run_name
        cp_callback = tf.keras.callbacks.ModelCheckpoint(filepath=checkpoint_path,
                                                         save_weights_only=True,
                                                         verbose=1)
        callbacks.append(cp_callback)

    return callbacks


def generate_dataset():
    """takes all images and generates a dataset"""
    utils.generate_csv(path_images, '_labels.csv')
    image_paths, image_labels = utils.load_labels_from_csv('_labels.csv')
    # Create a dataset
    dataset = tf.data.Dataset.from_tensor_slices((image_paths, image_labels))
    return dataset


def load_and_preprocess_image(image_path, labels):
    """function to load and preprocess images"""
    # Load image from file
    image = tf.io.read_file(image_path)
    image = tf.image.decode_image(image, channels=3)

    # Resize the image to the desired shape with padding
    image = tf.image.resize_with_pad(image, target_height=size[1], target_width=size[0])

    # Normalize image to values between -1 and 1
    image = (image / 127.5) - 1.0

    return image, labels


def generate_test_train_val(data):
    """split the whole dataset in train, validation and test"""

    dataset_size = len(data)

    # calculate size and split into three datasets
    train_size = int(0.7 * dataset_size)
    validation_size = int(0.15 * dataset_size)
    test_size = int(0.15 * dataset_size)
    train = data.take(train_size)
    test = data.skip(train_size)
    validation = test.skip(validation_size)
    test = test.take(test_size)

    train = train.batch(BATCH_SIZE)
    validation = validation.batch(BATCH_SIZE)
    test = test.batch(BATCH_SIZE)

    train = train.shuffle(buffer_size=200)
    validation = validation.shuffle(buffer_size=200)
    test = test.shuffle(buffer_size=200)

    train = train.prefetch(buffer_size=2)
    test = test.prefetch(buffer_size=2)
    validation = validation.prefetch(buffer_size=2)

    return train, test, validation


def get_model():
    """returns a model, depending on set Flags either loads a model or creates a new model"""
    if USE_SAVED_MODEL:
        new_model = tf.keras.models.load_model(saved_model_path)
    else:
        if transfer_learning:
            train_base_model = False
            base_model = tf.keras.applications.MobileNetV3Large(input_shape=(size[0], size[1], 3),
                                                                include_top=False,
                                                                weights="imagenet",
                                                                include_preprocessing=False,
                                                                )
        else:
            train_base_model = True
            base_model = tf.keras.applications.MobileNetV3Large(input_shape=(size[0], size[1], 3),
                                                                include_top=False,
                                                                weights=None,
                                                                include_preprocessing=False,
                                                                )
        # Freeze MobileNet
        base_model.trainable = train_base_model

        inputs = keras.Input(shape=(224, 224, 3))

        data_augmentation = keras.Sequential(
            [
                layers.RandomFlip("horizontal"),
                layers.RandomRotation(RANDOM_ROTATION),
            ]
        )

        x = data_augmentation(inputs)

        # BatchNormalization inference mode set with training
        model_base = base_model(x, training=train_base_model)
        model_base = keras.layers.GlobalAveragePooling2D()(model_base)
        model_base = keras.layers.Dropout(0.2)(model_base)

        # binary output, yes or no
        task_face = keras.layers.Dense(units=2, activation='softmax', name='is_face')(model_base)

        task_gender = keras.layers.Dense(units=3, activation='softmax', name='gender_output')(model_base)

        model_age = keras.layers.Dense(units=128, activation='relu', kernel_regularizer='l1')(model_base)

        model_age = keras.layers.Dense(units=64, activation='relu', kernel_regularizer='l1')(model_age)

        task_age = keras.layers.Dense(units=1, activation='relu', kernel_regularizer='l1', name='age_output')(model_age)

        outputs = [task_face, task_gender, task_age]

        new_model = keras.Model(inputs=inputs, outputs=outputs, name="MultiTask")
    return new_model


dataset = generate_dataset()

# Apply the loading and preprocessing function to the dataset
dataset = dataset.map(load_and_preprocess_image)
# split dataset and set dataset attributes
train_ds, test_ds, validation_ds = generate_test_train_val(dataset)

model = get_model()

if LOAD_CHECKPOINT:
    model.load_weights(load_checkpoint_path)
model.summary()

model.compile(
    optimizer=keras.optimizers.Adam(0.0008),
    loss={
        'is_face': 'sparse_categorical_crossentropy',
        'gender_output': 'sparse_categorical_crossentropy',
        'age_output': 'mse'
    },
    loss_weights={
        'is_face': is_face_weight,
        'gender_output': gender_weight,
        'age_output': age_weight,
    },
    metrics={
        'is_face': 'accuracy',
        'gender_output': 'accuracy',
        'age_output': 'mse'
    }
)

if do_training:
    model.fit(train_ds, epochs=TRAINING_EPOCHS, validation_data=validation_ds,
              callbacks=get_callbacks('normal'))

if SAVE_MODEL:
    model.save(model_save_path + model_name)

if CUSTOM_PREDICTION:
    print('prediction monkey')
    img = utils.prepare_image_for_predict('monkey.jpeg', size, 'custom_prediction/')
    prediction = model.predict(img)
    print(np.argmax(prediction[0]))
    print(np.argmax(prediction[1]))
    print(prediction[2][0])

    print('prediction animated character')
    img = utils.prepare_image_for_predict('animated_character.jpeg', size, 'custom_prediction/')
    prediction = model.predict(img)
    print(np.argmax(prediction[0]))
    print(np.argmax(prediction[1]))
    print(prediction[2][0])

    print('prediction real')
    img = utils.prepare_image_for_predict('real.jpeg', size, 'custom_prediction/')
    prediction = model.predict(img)
    print(np.argmax(prediction[0]))
    print(np.argmax(prediction[1]))
    print(prediction[2][0])

    print('prediction chris')
    img = utils.prepare_image_for_predict('chris.jpeg', size, 'custom_prediction/')
    prediction = model.predict(img)
    print(np.argmax(prediction[0]))
    print(np.argmax(prediction[1]))
    print(prediction[2][0])

if EVALUATE_MODEL:
    # true_labels

    predictions = model.predict(x=test_ds, verbose=1)

    print("---------Evaluating----------")
    res = model.evaluate(x=test_ds)

    face_accuracy = res[-3] * 100
    gender_accuracy = res[-2] * 100
    age_deviation = math.sqrt(res[-1])

    # Print the interpreted information
    print(f'Face Accuracy: {face_accuracy:.2f}%')
    print(f'Gender Accuracy: {gender_accuracy:.2f}%')
    print(f'Average Age Deviation: {age_deviation:.2f}')

    # Confusion Matrix
