import os

folderpath = 'archives\\training_fake\\'
files = os.listdir(folderpath)

for index, file in enumerate(files):
    # split = file.split('_')
    # os.rename(folderpath + file, folderpath + split[0] + '_' + split[1] + '_' + '1' + '_' + str(index) + '.jpeg')
    # os.rename(folderpath + file, folderpath + '0_2_0_' + str(index + 300000) + '.jpeg')
    continue
